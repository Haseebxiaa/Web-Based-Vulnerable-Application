﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FYPWork.Repository
{
    public class HomeModel
    {
        public bool login(string username ,string password)
        {
            return username.Equals("admin", StringComparison.CurrentCultureIgnoreCase) && 
                password.Equals("admin", StringComparison.CurrentCultureIgnoreCase);
        }
    }
}