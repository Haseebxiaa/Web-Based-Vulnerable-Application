﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FYPWork.Models;
using System.ComponentModel.DataAnnotations;

namespace FYPWork.ViewModels
{
    public class HomeViewModel
    {
        public Home account
        {
            get;
            set;
        }

        [Display(Name = "Remember Me?")]
        public bool remember
        {
            get;
            set;
        }

    }
}
