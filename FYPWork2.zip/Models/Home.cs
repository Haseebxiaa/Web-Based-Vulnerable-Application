﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace FYPWork.Models
{
    public class Home
    {
        [Display(Name = "Username")]
        public String Username
        {
            get;
            set;
        }


        [Display(Name = "Password")]
        public String Password
        {
            get;
            set;
        }

    }
}