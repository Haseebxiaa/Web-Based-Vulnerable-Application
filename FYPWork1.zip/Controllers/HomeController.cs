﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FYPWork.Models;
using FYPWork.Repository;
using FYPWork.ViewModels;
using System.Xml;
using System.Xml.Schema;
using System.Diagnostics;
using System.IO;
namespace FYPWork.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Display()
        {
            Home  account = checkCookie();
            if (account == null)
                return View();
            else
            {
                HomeModel accModel = new HomeModel();
                if (accModel.login(account.Username, account.Password))
                {
                    Session["username"] = account.Username;
                    return View("Welcome");
                }
                else
                {
                    //ViewBag.Error = "Account's Invalid";
                    return View();
                }
            }
        }

        public ActionResult Logout()
        {

            //REmoving the session
            Session.Remove("username");
            //Remove cookie
            if (Response.Cookies["username"] != null)
            {
                HttpCookie ckUsername = new HttpCookie("usename");
                ckUsername.Expires = DateTime.Now.AddDays(-1d);
                Response.Cookies.Add(ckUsername);

            }
            if (Response.Cookies["password"] != null)
            {
                HttpCookie ckPassword = new HttpCookie("password");
                ckPassword.Expires = DateTime.Now.AddDays(-1d);
                Response.Cookies.Add(ckPassword);

            }
            return View("Index");
        }

        [HttpPost]
        public ActionResult Login(HomeViewModel avm)
        {
            HomeModel accModel = new HomeModel();
            if (accModel.login(avm.account.Username, avm.account.Password))
            {
                Session["username"] = avm.account.Username;
                if (avm.remember)
                {
                    HttpCookie ckUsername = new HttpCookie("usename");
                    ckUsername.Expires = DateTime.Now.AddSeconds(3600);
                    ckUsername.Value = avm.account.Username;
                    Response.Cookies.Add(ckUsername);

                    HttpCookie ckPassworde = new HttpCookie("usename");
                    ckPassworde.Expires = DateTime.Now.AddSeconds(3600);
                    ckPassworde.Value = avm.account.Password;
                    Response.Cookies.Add(ckPassworde);
                }
                return View("AdminPanel");
            }
            else
            {
                ViewBag.Error = "Account's InValid";
                return View("Display");
            }

        }


        public Home checkCookie()
        {
            Home account = null;
            String username = string.Empty, password = string.Empty;
            if (Request.Cookies["username"] != null)
                username = Request.Cookies["username"].Value;
            if (Request.Cookies["password"] != null)
                password = Request.Cookies["password"].Value;
            if (String.IsNullOrEmpty(username) && String.IsNullOrEmpty(password))
                account = new Home { Username = username, Password = password };
            return account;
        }

        public ActionResult Index()
        {
            return View();

        }

        public ActionResult adminlogin()
        {
            return View();

        }
        public ActionResult Xpath()
        {

            return View();

        }
        public ActionResult Xquery()
        {
            return View();

        }

        public ActionResult Scenario1()
        {
            return View();

        }

        public ActionResult Scenario2()
        {
            return View();

        }


        public ActionResult Scenario3()
        {
            return View();

        }


        public ActionResult Scenario4()
        {
            return View();

        }

        public ActionResult Scenariosp1()
        {
            return View();

        }
        public ActionResult Scenariosp2()
        {
            return View();

        }


        [HttpPost]
        public ActionResult Normal(FormCollection collection)
        {
            string x = collection["text1"];
            SparqlNormal(x);
            return View("Sparql");
        }

        [HttpPost]
        public ActionResult Hack(FormCollection collection)
        {
            string x = collection["text1"];
            SparqlHack(x);
            return View("Sparql");
        }

        public ActionResult SparqlNormal(string text)
        {
            string inpName = "\"" + text + "\"";

            string currpath = Server.MapPath("~");
            string path = "-jar" + " \"" + currpath + "dist\\Sparql.jar\" " + inpName;
            string output = executeJar(path);
            ViewBag.JavaOutput = output;


            return View();

        }


        public ActionResult SparqlHack(string text)
        {
            string inpName = "\"" + text + "\"";

            string currpath = Server.MapPath("~");
            string path = "-jar" + " \"" + currpath + "dist\\SparqlHack.jar\" " + inpName;

            string output = executeJar(path);
            ViewBag.JavaOutput = output;

            //string output1 = executeJar("-jar C:\\Users\\Hassan\\Documents\\NetBeansProjects\\SparqlHack\\dist\\SparqlHack.jar");
            //ViewBag.JavaOutput2 = output1;

            //string output2 = executeJar("-jar C:\\Users\\Hassan\\Documents\\NetBeansProjects\\BlindSparql\\dist\\BlindSparql.jar");
            //ViewBag.JavaOutput3 = output2;

            //string output3 = executeJar("-jar C:\\Users\\Hassan\\Documents\\NetBeansProjects\\BlindSparqlHack\\dist\\BlindSparqlHack.jar");
            //ViewBag.JavaOutput4 = output3;

            return View();

        }

        [HttpPost]
        public ActionResult BlindNormal(FormCollection collection)
        {
            string x = collection["text1"];
            SparqlBlindNormal(x);
            return View("Sparql");
        }

        [HttpPost]
        public ActionResult BlindHack(FormCollection collection)
        {
            string x = collection["text1"];
            SparqlBlindHack(x);
            return View("Sparql");
        }

        public ActionResult SparqlBlindNormal(string text)
        {
            string inpName = "\"" + text + "\"";

            string currpath = Server.MapPath("~");
            string path = "-jar" + " \"" + currpath + "dist\\BlindSparql.jar\" " + inpName;
            string output = executeJar(path);
            ViewBag.JavaOutput = output;


            return View();

        }


        public ActionResult SparqlBlindHack(string text)
        {
            string inpName = "\"" + text + "\"";

            string currpath = Server.MapPath("~");
            string path = "-jar" + " \"" + currpath + "dist\\BlindSparqlHack.jar\" " + inpName;

            string output = executeJar(path);
            ViewBag.JavaOutput = output;

            return View();

        }

        public ActionResult Sparql()
        {
            return View();

        }

        private string executeJar(String path)
        {
            int exitcode;
            ProcessStartInfo ProcessInfo;
            Process process;
            //Console.WriteLine("Start");
            ProcessInfo = new
            ProcessStartInfo("java.exe", path);

            ProcessInfo.CreateNoWindow = true;
            ProcessInfo.UseShellExecute = false;
            // redirecting standard output and error
            ProcessInfo.RedirectStandardError = true;
            ProcessInfo.RedirectStandardOutput = true;

            process = Process.Start(ProcessInfo);

            process.WaitForExit();
            // Console.WriteLine("End");

            //Reading output and error
            String output = process.StandardOutput.ReadToEnd();
            String error = process.StandardError.ReadToEnd();

            exitcode = process.ExitCode;


            process.Close();
            return output;

        }

        public ActionResult SparqlScenario1()
        {
            return View();

        }

        public ActionResult SparqlScenario2()
        {
            return View();

        }

        public ActionResult VideoTutorial()
        {
            return View();

        }

        public ActionResult AdminPanel()
        {

            return View();


        }


        public ActionResult ContactUs()
        {
            return View();


        }
        [HttpPost]
        public ActionResult VerifyyXML()
        {
            String message = "No message";

            try
            {
                XmlDocument docXML = new XmlDocument();

                docXML.Load(Server.MapPath("../samples/sample.xml"));
            }
            catch (XmlException e)
            {
                message = e.Message;

            }
            ViewBag.xmlVerificationValuee = message;
            return View("AdminPanel");
        }

        [HttpPost]
        public ActionResult VerifyXML()
        {
            String message = "No message";

            try
            {
                XmlDocument docXML = new XmlDocument();

                docXML.Load(Server.MapPath("../samples/sample.xml"));
            }
            catch (XmlException e)
            {
                message = e.Message;

            }
            ViewBag.xmlVerificationValuee = message;
            return View("Xpath");
        }

        [HttpPost]
        public ActionResult Uploadd()
        {
            if (Request.Files.Count > 0)
            {
                var file = Request.Files[0];

                if (file != null && file.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(file.FileName);
                    var path = Path.Combine(Server.MapPath("../samples"), fileName);
                    file.SaveAs(path);
                }
            }
            VerifyXML();
            return RedirectToAction("AdminPanel");
        }

        [HttpPost]
        public ActionResult Upload()
        {
            if (Request.Files.Count > 0)
            {
                var file = Request.Files[0];

                if (file != null && file.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(file.FileName);
                    var path = Path.Combine(Server.MapPath("../samples"), fileName);
                    file.SaveAs(path);
                }
            }
           VerifyXML();
            return RedirectToAction("Xpath");
        }
    }

}
