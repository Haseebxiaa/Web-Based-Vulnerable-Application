<?php


include("admin/settings.php");

// Connection settings
$server = $db_server;
$username = $db_username;
$password = $db_password;
$database = $db_name;


?>