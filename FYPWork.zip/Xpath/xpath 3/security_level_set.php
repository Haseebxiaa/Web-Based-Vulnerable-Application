<?php


include("security.php");
include("selections.php");
include("admin/settings.php");

if(isset($_POST["form"]) && isset($_POST["security_level"]))    
{
    
    $security_level_cookie = $_POST["security_level"];
    
    switch($security_level_cookie)
    {

        case "0" :

            $security_level_cookie = "0";
            break;

        case "1" :

            $security_level_cookie = "1";
            break;

        case "2" :

            $security_level_cookie = "2";
            break;

        default : 

            $security_level_cookie = "0";
            break;

    }

    if($evil_bee == 1)
    {

        setcookie("security_level", "666", time()+60*60*24*365, "/", "", false, false);

    }
    
    else        
    {
      
        setcookie("security_level", $security_level_cookie, time()+60*60*24*365, "/", "", false, false);
        
    }

    header("Location: " . $_SERVER["SCRIPT_NAME"]);
    
    exit;

}
        
?>
<!DOCTYPE html>
<html>
    


<div id="main">
        
    <h1>Set Security Level</h1>

    <p>Your security level is <b><?php echo $security_level ?></b>.</p>

    <form action="<?php echo($_SERVER["SCRIPT_NAME"]);?>" method="POST">

        <p><label for="security_level">Set the security level:</label><br />

        <select name="security_level">

            <option value="0">low</option>
            <option value="1">medium</option>
            <option value="2">high</option>

        </select>     

        <button type="submit" name="form" value="submit">Set</button>

        </p>

    </form> 
    
</div>
    


    
</div>
      
</body>
    
</html>