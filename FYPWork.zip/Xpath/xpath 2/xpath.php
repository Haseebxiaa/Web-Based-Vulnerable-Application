<!DOCTYPE html>
<html>




<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" type="text/css">
    <link href="assets/fonts/profession/style.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/bootstrap-fileinput/css/fileinput.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/bootstrap-select/css/bootstrap-select.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/bootstrap-wysiwyg/bootstrap-wysiwyg.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/profession-black-green.css" rel="stylesheet" type="text/css" id="style-primary">

    <link rel="shortcut icon" type="image/x-icon" href="assets/favicon.png">
    
    <title>WEB BASED VULNERABLE APPLICATION </title>
</head>


<body class="hero-content-dark footer-dark">

<div class="page-wrapper">
    <div class="header-wrapper">
    <div class="header">
        <div class="header-top">
            <div class="container">
                <div class="header-brand">
                    <div class="header-logo">
                        <a href="#">
                            <i class="profession profession-logo"></i>
                            <span class="header-logo-text">Xpath Injection <span class="header-logo-highlight"></span>2</span>
                        </a>
                    </div><!-- /.header-logo-->

                    
                </div><!-- /.header-brand -->

                
                    
                   
                

              
            </div><!-- /.container -->
        </div><!-- /.header-top -->

        <div class="header-bottom">
            <div class="container">
                <ul class="header-nav nav nav-pills collapse">
                    <li class="active">
                        <a href="#">Home</a>
                        
                    </li>

                   
                    </ul><!-- /.header-search -->
            </div><!-- /.container -->
        </div><!-- /.header-bottom -->
    </div><!-- /.header -->
</div><!-- /.header-wrapper-->



      

      <div align="center">

    <form action="<?php echo($_SERVER["SCRIPT_NAME"]);?>" method="GET">

        <p><label for="login">User Login:</label><br />
        
		<input  type="text" id="login" class="center" placeholder="login" name="login" autocomplete="off"> </input>
        <p><label for="password">User Password:</label><br />
        
		<input  type="password" id="password" class="center" placeholder="Password" name="password" autocomplete="off"> </input>
      
		<div align="bottom"> <button class="btn btn-default" name="form" type="submit" value="submit">Search</button></div>

    </form>
	
	</div>
   </body>

 <?php


if(isset($_REQUEST["login"]) & isset($_REQUEST["password"]))
{
//take values from the HTML form
    $login = $_REQUEST["login"];
    $password = $_REQUEST["password"];


    // Loads the XML file saved in the same directory
    $xml = simplexml_load_file("accountinfo.xml");

    // Executes the XPath search
    $result = $xml->xpath("/users/user[login='" . $login . "' and password='" . $password . "']");

    if($result)
    {

        $message =  "<br>Accepted User: <b>" . ucwords($result[0]->login) . "</b><br>Your Account Number: <b>" . $result[0]->accountd . "</b>";
        echo $message;
    }

    else
    {

        $message = "Your supplied credentials are invalid!";
	    echo $message;
    }
   }
?>


</div><!-- /.page-wrapper -->



<script type="text/javascript" src="assets/js/jquery.js"></script>
<script type="text/javascript" src="assets/js/jquery.ezmark.js"></script>

<script type="text/javascript" src="assets/libraries/bootstrap-sass/javascripts/bootstrap/collapse.js"></script>
<script type="text/javascript" src="assets/libraries/bootstrap-sass/javascripts/bootstrap/dropdown.js"></script>
<script type="text/javascript" src="assets/libraries/bootstrap-sass/javascripts/bootstrap/tab.js"></script>
<script type="text/javascript" src="assets/libraries/bootstrap-sass/javascripts/bootstrap/transition.js"></script>
<script type="text/javascript" src="assets/libraries/bootstrap-fileinput/js/fileinput.min.js"></script>
<script type="text/javascript" src="assets/libraries/bootstrap-select/js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="assets/libraries/bootstrap-wysiwyg/bootstrap-wysiwyg.min.js"></script>

<script type="text/javascript" src="assets/libraries/cycle2/jquery.cycle2.min.js"></script>
<script type="text/javascript" src="assets/libraries/cycle2/jquery.cycle2.carousel.min.js"></script>

<script type="text/javascript" src="assets/libraries/countup/countup.min.js"></script>

<script type="text/javascript" src="assets/js/profession.js"></script>


</body>

<!-- Mirrored from preview.byaviators.com/template/profession/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 09 Oct 2015 07:03:56 GMT -->
</html>